from setuptools import setup

setup(
    name='RUL_simplified',
    version='0.1.1',    
    description='RUL_simplified',
    url='https://github.com/gavbdheiver/RUL_simplified-0.1.0.tar.gz',
    author='Dheiver Santos',
    author_email ='dheiver.santos@gmail.com',
    install_requires=['numpy']
)