Meta-Data

Description rul calculation package

name  Dheiver Santos

Name of your package. RUL_SIMPLIFIED

version  version='0.1.0'

Current version of your pip package.

scripts

author and author_email Dheiver dheiver.santos@gmail.com

description

A short description of the package.

Use for other package dependencies.

classifiers

Contains all the classifiers of your project.